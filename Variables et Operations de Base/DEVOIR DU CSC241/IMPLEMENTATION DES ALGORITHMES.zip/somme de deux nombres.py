nombre_1=int(input("entrez le 1 er nombre:"))
nombre_2=int(input("entrez le 2eme nombre"))
nombre_3=nombre_1+nombre_2
print("le resultat de la somme du 1er et du 2eme nombre est:",nombre_3)