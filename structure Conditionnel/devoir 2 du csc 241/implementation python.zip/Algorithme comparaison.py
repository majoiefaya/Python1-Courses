a=int(input("entrer A: "))
b=int(input("entrer B: "))
if a>b:
    print(" A est superieur à B")
elif a<b:
    print(" A est inferieur à B")
else:
    print(" A est égale a B")
