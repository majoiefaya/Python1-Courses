nombre=int(input("entrer votre nombre:  "))
if nombre%2==0:
    print(nombre,"est pair")
else:
    print(nombre,"est impair")