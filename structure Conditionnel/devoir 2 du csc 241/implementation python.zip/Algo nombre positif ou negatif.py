nombre=int(input("entrer votre nombre: "))
if nombre>0:
    print(nombre ,"est positif")
else:
    print(nombre ,"est négatif")