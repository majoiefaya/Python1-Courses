nombre1=int(input("entrer le nombre 1: "))
nombre2=int(input("entrer le nombre 2: "))
if nombre1>0 and nombre2>0:
    print("le produit des deux nombres est positif")
elif nombre1<0 and nombre2<0:
    print("le produit des deux nombres est positif")
else:
    print("le produit des deux nombres est negatif")